using Godot;

public partial class CSharpBootstrap : Node
{
	public override void _Ready()
	{
		GD.Print("C# bootstrap loaded");
	}
}
