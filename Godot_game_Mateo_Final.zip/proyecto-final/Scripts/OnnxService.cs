using Godot;

public partial class OnnxService : Node
{
	private ONNXInference _inferencer;

	public void Init(string modelPath, int batchSize)
	{
		GD.Print($"[OnnxService] Init: {modelPath}");
		_inferencer = new ONNXInference();
		_inferencer.Initialize(modelPath, batchSize);
	}

	public Godot.Collections.Dictionary<string, Godot.Collections.Array<float>> RunInference(
		Godot.Collections.Dictionary<string, Godot.Collections.Array<float>> obs,
		int stateIns
	)
	{
		if (_inferencer == null)
		{
			GD.Print("[OnnxService] Inference called before init.");
			return new Godot.Collections.Dictionary<string, Godot.Collections.Array<float>>
			{
				{ "output", new Godot.Collections.Array<float>() },
				{ "state_outs", new Godot.Collections.Array<float>() }
			};
		}
		return _inferencer.RunInference(obs, stateIns);
	}

	public void Stop()
	{
		if (_inferencer != null)
		{
			_inferencer.FreeDisposables();
			_inferencer = null;
		}
	}
}
