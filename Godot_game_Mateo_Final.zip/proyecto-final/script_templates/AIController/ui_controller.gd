extends CanvasLayer

@export var sync_path: NodePath
@export var onnx_model_path: String = "res://models/ppo_speedrun_latest.onnx"
@onready var sync_node := get_node(sync_path)

@onready var toggle_button = $"Control/Jugar con IA"

var ia_active := false

func _ready():
	toggle_button.pressed.connect(_on_button_pressed)
	toggle_button.focus_mode = Control.FOCUS_NONE
	update_text()

func _on_button_pressed():
	set_ai_enabled(!ia_active) # reutiliza la misma logica

func update_text():
	toggle_button.text = "Jugar sin IA" if ia_active else "Jugar con IA"

func set_ai_enabled(enable: bool):
	if ia_active == enable:
		return

	ia_active = enable
	var level := get_tree().current_scene
	if level and level.has_method("set_ghost_enabled"):
		level.set_ghost_enabled(ia_active)

	if ia_active:
		print("FANTASMA ACTIVADO")

		# Inferencia local (ONNX)
		sync_node.start_onnx_mode(onnx_model_path)

	else:
		print("FANTASMA DESACTIVADO")

		sync_node.stop_onnx_mode()

	update_text()
