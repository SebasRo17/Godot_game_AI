extends Node2D

var episode_finished := false
var run_time := 0.0
var _ghost: CharacterBody2D = null
var _player: CharacterBody2D = null
var _ai_controller: Node = null
var _prev_player_dead := false

const GHOST_SCENE_PATH := "res://Objects/Player.tscn"
const GHOST_NAME := "GhostPlayer"

# Called when the node enters the scene tree for the first time.
func _ready():
	$goal_area_2d.goal_reached_signal.connect(_on_goal_reached)
	_player = get_node_or_null("CharacterBody2D") as CharacterBody2D
	_ai_controller = get_node_or_null("Sync/AIController2D")
	if $CanvasLayer/Control/CompletionLabel:
		$CanvasLayer/Control/CompletionLabel.visible = false

func _on_goal_reached():
	print("EPISODIO TERMINADO (VICTORIA)")
	episode_finished = true
	if $CanvasLayer/Control/CompletionLabel:
		$CanvasLayer/Control/CompletionLabel.visible = true
	

func _physics_process(delta):
	if episode_finished:
		return

	run_time += delta
	$CanvasLayer/Control/TimerLabel.text = _format_time(run_time)
	_check_player_death()

func _format_time(t: float) -> String:
	var minutes = int(t) / 60
	var seconds = int(t) % 60
	var millis = int((t - int(t)) * 1000)
	return "%02d:%02d.%03d" % [minutes, seconds, millis]


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func set_ghost_enabled(enable: bool) -> void:
	if enable:
		run_time = 0.0
		if $CanvasLayer/Control/CompletionLabel:
			$CanvasLayer/Control/CompletionLabel.visible = false
		_reset_player_to_spawn()
		if _ghost == null:
			_ghost = _create_ghost()
		if _ghost == null:
			return
		_ghost.visible = true
		_ghost.process_mode = Node.PROCESS_MODE_INHERIT
		_reset_ghost_to_player()
		_set_ai_target(_ghost)
	else:
		run_time = 0.0
		if $CanvasLayer/Control/CompletionLabel:
			$CanvasLayer/Control/CompletionLabel.visible = false
		if _ghost:
			_ghost.queue_free()
			_ghost = null
		_set_ai_target(null)

func _create_ghost() -> CharacterBody2D:
	var ghost_scene := load(GHOST_SCENE_PATH)
	if ghost_scene == null:
		push_warning("[DemoLevel] No se pudo cargar escena del ghost.")
		return null

	var ghost := ghost_scene.instantiate() as CharacterBody2D
	if ghost == null:
		push_warning("[DemoLevel] No se pudo instanciar ghost.")
		return null

	ghost.name = GHOST_NAME
	if "allow_human_input" in ghost:
		ghost.allow_human_input = false
	if "allow_ai_input" in ghost:
		ghost.allow_ai_input = true
	if "is_ghost" in ghost:
		ghost.is_ghost = true

	ghost.collision_layer = 2
	ghost.collision_mask = 1
	if _player:
		ghost.add_collision_exception_with(_player)
	ghost.visible = false
	ghost.process_mode = Node.PROCESS_MODE_DISABLED

	add_child(ghost)
	return ghost

func _reset_ghost_to_player() -> void:
	if _ghost == null or _player == null:
		return
	_ghost.global_position = _player.global_position
	if "respawn_point" in _ghost and "respawn_point" in _player:
		_ghost.respawn_point = _player.respawn_point
	if _ghost.has_method("respawn"):
		_ghost.respawn()

func _set_ai_target(target: CharacterBody2D) -> void:
	if _ai_controller == null:
		return
	if _ai_controller.has_method("set_player_target"):
		_ai_controller.set_player_target(target)

func _check_player_death() -> void:
	if _player == null:
		return
	var is_dead_now: bool = bool(_player.is_dead)
	if is_dead_now and not _prev_player_dead:
		_reset_ghost_to_player()
	_prev_player_dead = is_dead_now

func _reset_player_to_spawn() -> void:
	if _player == null:
		return
	var spawn := get_node_or_null("SpawnPoint") as Marker2D
	if spawn:
		if "respawn_point" in _player:
			_player.respawn_point = spawn.global_position
		_player.global_position = spawn.global_position
		_player.velocity = Vector2.ZERO
		_player.is_dead = false
		_player.currentState = "idle"
		_player.previousState = ""
		_player.currentSpeed = 0.0
		if _player.has_method("respawn"):
			_player.respawn()
	else:
		if _player.has_method("respawn"):
			_player.respawn()
